"""Defines ROS node executables.

The python nodes in this package are defined as thin wrapper scripts in the scripts/ directory.
Each wrapper script has a corresponding module in this directory. Splitting the executable from
the code makes testing easier and is inline with good practices for developing python executables.
"""
import sys
sys.path.append("/home/lao-tang/Documents/demo_code/ros_qt/src/ws_rtk/nmea_navsat_driver/src/libnmea_navsat_driver")
from driver import RosNMEADriver
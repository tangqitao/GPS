"""ROS nodes and supporting python code for ROS nmea_navsat_driver package."""
